#import logging
import asyncio
from random import random, randrange, randint
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart , Command
from aiogram.types import Message, CallbackQuery


#API BOTA
API_TOKEN = '7903656656:AAHmSnosRXxfZSrlEPCF4AwbEr7P-bWDjA8'


#logging.basicConfig(level = logging.INFO)

max = 0

bot = Bot(token = API_TOKEN)
dp = Dispatcher()



@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer('Привет, введи команду /help чтобы узнать список команд')



@dp.message(F.text == 'лол')
async def get_help(message: Message):
    await message.answer('1./help, 2./info, 3./otchim, 4./photo, 5./money')

@dp.message(Command('help'))
async def get_help(message: Message):
    await message.answer('1./help, 2./info, 3./otchim, 4./photo, 5./money')


@dp.message(Command('otchim'))
async def get_otchim(message: Message):
    global max
    rand = randint(0, 101)
    if rand > max:
        max = rand
    await message.reply(f'У меня {rand} отчимов. Максимальное количество: {max}')

@dp.message(Command('info'))
async def get_info(message: Message):
    await message.reply('Привет, я бот Олег я могу сделать всё что ты хочешь, и выпить всё что не приколочено :)')

@dp.message(Command('photo'))
async def get_photo(message: Message):
    await message.answer_photo(photo='https://lastfm.freetls.fastly.net/i/u/ar0/54649dced375411fc131f3c438e3009a.png',
                               caption= 'Это Аня')

@dp.message(Command('money'))
async def get_money(message: Message):
    randm = randint(1, 2)
    if randm == 1:
        await message.reply('Орёл епт')
    elif randm == 2:
        await message.reply('Решка епт')


@dp.message()
async def echo(message: Message):
    await message.reply('Матери своей так говорить будешь')





async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())
    #from aiogram import executor
    #executor.start_polling(dp, skip_updates=True)